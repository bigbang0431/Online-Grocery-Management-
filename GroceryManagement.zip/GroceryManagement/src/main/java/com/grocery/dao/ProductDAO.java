package com.grocery.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import com.grocery.beans.Product;
import com.grocery.utils.DBConnection;

public class ProductDAO {

    // Method to add a new product
    public boolean addProduct(Product product) {
        String sql = "INSERT INTO products (productName, productDescription, price, category) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, product.getProductName());
            stmt.setString(2, product.getProductDescription());
            stmt.setDouble(3, product.getPrice());
            stmt.setString(4, product.getCategory());
            int rowsInserted = stmt.executeUpdate();
            return rowsInserted > 0;
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Method to get all products
    public List<Product> getAllProducts() {
        List<Product> productList = new ArrayList<>();
        String sql = "SELECT * FROM products";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Product product = new Product(
                    rs.getInt("productId"), // Ensure column names match database schema
                    rs.getString("productName"),
                    rs.getString("productDescription"),
                    rs.getDouble("price"),
                    rs.getString("category")
                );
                productList.add(product);
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        System.out.println("Products fetched from database: " + productList); // Debugging line
        return productList;
    }

    // Method to delete a product by ID
    public boolean deleteProduct(int id) {
        String sql = "DELETE FROM products WHERE productId = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            int rowsDeleted = stmt.executeUpdate();
            return rowsDeleted > 0;
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    public boolean updateProduct(Product product) {
        String sql = "UPDATE products SET productName = ?, productDescription = ?, price = ?, category = ? WHERE productId = ?";
        boolean rowUpdated = false;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, product.getProductName());
            stmt.setString(2, product.getProductDescription());
            stmt.setDouble(3, product.getPrice());
            stmt.setString(4, product.getCategory());
            stmt.setInt(5, product.getProductId());

            int rowsAffected = stmt.executeUpdate();
            rowUpdated = rowsAffected > 0;
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }

        return rowUpdated;
    }
    
    public Product getProductById(int id) {
        String sql = "SELECT * FROM products WHERE productId = ?";
        Product product = null;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    int productId = rs.getInt("productId");
                    String productName = rs.getString("productName");
                    String productDescription = rs.getString("productDescription");
                    double price = rs.getDouble("price");
                    String category = rs.getString("category");

                    product = new Product(productId, productName, productDescription, price, category);
                }
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }

        return product;
    }
    
    
    
   

    
}
