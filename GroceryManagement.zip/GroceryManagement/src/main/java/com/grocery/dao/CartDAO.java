package com.grocery.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.grocery.beans.CartItem;
import com.grocery.utils.DBConnection;

public class CartDAO {

    public boolean addProductToCart(int productId, int quantity) {
        boolean isSuccess = false;
        String sql = "INSERT INTO cart(productId, quantity) VALUES(?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, productId);
            stmt.setInt(2, quantity);
            int rowsAffected = stmt.executeUpdate();
            isSuccess = rowsAffected > 0;
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return isSuccess;
    }

    public boolean updateProductQuantity(int productId, int quantity) {
        boolean isSuccess = false;
        String sql = "UPDATE cart SET quantity = ? WHERE productId = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, quantity);
            stmt.setInt(2, productId);
            int rowsAffected = stmt.executeUpdate();
            isSuccess = rowsAffected > 0;
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return isSuccess;
    }

    public boolean removeProductFromCart(int productId) {
        boolean isSuccess = false;
        String sql = "DELETE FROM cart WHERE productId = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, productId);
            int rowsAffected = stmt.executeUpdate();
            isSuccess = rowsAffected > 0;
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return isSuccess;
    }

    public List<CartItem> getCartItems() {
        List<CartItem> cartItems = new ArrayList<>();
        String sql = "SELECT cart.productId, products.productName, cart.quantity, products.price " +
                     "FROM cart " +
                     "JOIN products ON cart.productId = products.productId";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                CartItem item = new CartItem();
                item.setProductId(rs.getInt("productId"));
                item.setProductName(rs.getString("productName"));
                item.setQuantity(rs.getInt("quantity"));
                item.setPrice(rs.getDouble("price"));
                cartItems.add(item);
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return cartItems;
    }

}
