package com.grocery.dao;

import java.sql.*;
import com.grocery.beans.Admin;
import com.grocery.utils.DBConnection;

public class AdminDAO {

    // Method to save a new admin in the database
    public void saveAdmin(Admin newAdmin) {
        String sql = "INSERT INTO admins (username, password, email, role) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, newAdmin.getUsername());
            stmt.setString(2, newAdmin.getPassword());
            stmt.setString(3, newAdmin.getEmail());
            stmt.setString(4, newAdmin.getRole()); // Use the role provided
            stmt.executeUpdate();
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
