package com.grocery.services;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.grocery.beans.Product;
import com.grocery.beans.CartItem;
import com.grocery.dao.ProductDAO;
import com.grocery.dao.CartDAO;
import java.util.List;

@WebServlet("/CartServlet")
public class CartServlet extends HttpServlet {
    private CartDAO cartDAO;
    private ProductDAO productDAO;

    @Override
    public void init() {
        cartDAO = new CartDAO();
        productDAO = new ProductDAO();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("addToCart".equals(action)) {
            addToCart(request, response);
        } else if ("updateCart".equals(action)) {
            updateCart(request, response);
        } else if ("removeFromCart".equals(action)) {
            removeFromCart(request, response);
        }
    }

    private void addToCart(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int productId = Integer.parseInt(request.getParameter("productId"));
        int quantity = Integer.parseInt(request.getParameter("quantity"));

        Product product = productDAO.getProductById(productId);
        if (product != null) {
            boolean isAdded = cartDAO.addProductToCart(productId, quantity);
            if (isAdded) {
                request.setAttribute("successMessage", "Product added to cart successfully.");
            } else {
                request.setAttribute("errorMessage", "Failed to add product to cart.");
            }
        } else {
            request.setAttribute("errorMessage", "Product not found.");
        }

        // Retrieve updated cart items
        List<CartItem> cartItems = cartDAO.getCartItems();
        request.setAttribute("cartItems", cartItems);

        request.getRequestDispatcher("wishlist.jsp").forward(request, response);
    }


    private void updateCart(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int productId = Integer.parseInt(request.getParameter("productId"));
        int quantity = Integer.parseInt(request.getParameter("quantity"));

        boolean isUpdated = cartDAO.updateProductQuantity(productId, quantity);
        if (isUpdated) {
            request.setAttribute("successMessage", "Cart updated successfully.");
        } else {
            request.setAttribute("errorMessage", "Failed to update cart.");
        }

        // Retrieve updated cart items
        List<CartItem> cartItems = cartDAO.getCartItems();
        request.setAttribute("cartItems", cartItems);

        request.getRequestDispatcher("wishlist.jsp").forward(request, response);
    }

    private void removeFromCart(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int productId = Integer.parseInt(request.getParameter("productId"));

        boolean isRemoved = cartDAO.removeProductFromCart(productId);
        if (isRemoved) {
            request.setAttribute("successMessage", "Product removed from cart successfully.");
        } else {
            request.setAttribute("errorMessage", "Failed to remove product from cart.");
        }

        // Retrieve updated cart items
        List<CartItem> cartItems = cartDAO.getCartItems();
        request.setAttribute("cartItems", cartItems);

        request.getRequestDispatcher("wishlist.jsp").forward(request, response);
    }
}
