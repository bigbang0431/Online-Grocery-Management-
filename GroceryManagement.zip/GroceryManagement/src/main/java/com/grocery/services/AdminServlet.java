package com.grocery.services;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.grocery.beans.Admin;
import com.grocery.dao.AdminDAO;

@WebServlet(name = "AdminServlet", urlPatterns = { "/AdminServlet" })
public class AdminServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    // DAO instance
    private AdminDAO adminDAO;

    @Override
    public void init() throws ServletException {
        // Initialize DAO
        adminDAO = new AdminDAO();
    }

    /**
     * Handles POST requests for adding a new admin.
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String email = request.getParameter("email");

        // Validate the input
        if (username == null || password == null || email == null || username.isEmpty() || password.isEmpty() || email.isEmpty()) {
            request.setAttribute("errorMessage", "All fields are required.");
            request.getRequestDispatcher("add-admin.jsp").forward(request, response);
            return;
        }

        // Create Admin object
        Admin newAdmin = new Admin(username, password, email, "admin"); // Assuming role is "admin"

        try {
            // Add the new admin to the database
            adminDAO.saveAdmin(newAdmin);

            // Set success message and redirect to admin dashboard
            request.getSession().setAttribute("successMessage", "Admin added successfully.");
            response.sendRedirect("admin-dashboard.jsp");
        } catch (Exception e) {
            e.printStackTrace();
            // Set error message and forward back to the add admin page
            request.setAttribute("errorMessage", "An error occurred while adding the admin.");
            request.getRequestDispatcher("add-admin.jsp").forward(request, response);
        }
    }
}
