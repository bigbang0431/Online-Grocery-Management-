package com.grocery.services;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.grocery.beans.Product;
import com.grocery.dao.ProductDAO;

@WebServlet("/AddProductServlet")
public class AddProductServlet extends HttpServlet {
    private ProductDAO productDAO;

    @Override
    public void init() {
        productDAO = new ProductDAO();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String name = request.getParameter("name");
        String description = request.getParameter("description");
        double price;
        String category = request.getParameter("category");

        try {
            price = Double.parseDouble(request.getParameter("price"));
        } catch (NumberFormatException e) {
            request.setAttribute("errorMessage", "Invalid price format. Please enter a valid number.");
            request.getRequestDispatcher("add-product.jsp").forward(request, response);
            return;
        }

        // Create a new Product object
        Product product = new Product(name, description, price, category);

        // Save product to the database
        boolean isProductAdded = productDAO.addProduct(product);
        if (isProductAdded) {
            request.setAttribute("successMessage", "Product added successfully!");
        } else {
            request.setAttribute("errorMessage", "Failed to add product. Please try again.");
        }

        // Forward to the JSP to display the result
        request.getRequestDispatcher("add-product.jsp").forward(request, response);
    }
}
