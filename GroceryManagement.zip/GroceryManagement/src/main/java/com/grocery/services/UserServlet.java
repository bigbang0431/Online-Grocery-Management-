package com.grocery.services;

import java.io.IOException;
import javax.servlet.*;
import javax.servlet.http.*;
import com.grocery.dao.UserDAO;
import com.grocery.beans.User;

public class UserServlet extends HttpServlet {
    private UserDAO userDAO;

    @Override
    public void init() {
        userDAO = new UserDAO();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        if ("register".equals(action)) {
            registerUser(request, response);
        } else if ("login".equals(action)) {
            loginUser(request, response);
        } else if ("updateProfile".equals(action)) {
            updateProfile(request, response);
        }
    }

    private void registerUser(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String email = request.getParameter("email");
        String role = "customer"; // Default role for registration

        User user = new User(username, password, email, role);
        userDAO.saveUser(user);

        // Set success message
        request.setAttribute("successMessage", "User registered successfully!");
        // Forward to registration confirmation page
        RequestDispatcher dispatcher = request.getRequestDispatcher("registration-success.jsp");
        dispatcher.forward(request, response);
    }

    private void loginUser(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        User user = userDAO.validateUser(username, password);
        if (user != null) {
            HttpSession session = request.getSession();
            session.setAttribute("user", user); // Store the entire user object
            session.setAttribute("username", user.getUsername()); // Store username separately

            // Redirect based on user role
            if ("admin".equals(user.getRole())) {
                response.sendRedirect("admin-dashboard.jsp");
            } else {
                response.sendRedirect("header.jsp");
            }
        } else {
            response.sendRedirect("login.jsp?error=invalid");
        }
    }



    private void updateProfile(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        if (user != null) {
            String email = request.getParameter("email");
            user.setEmail(email);

            userDAO.updateUser(user);

            // Set success message
            request.setAttribute("successMessage", "Profile updated successfully!");
            // Redirect to profile page
            response.sendRedirect("profile.jsp");
        } else {
            response.sendRedirect("login.jsp?error=not_logged_in");
        }
    }
}