package com.grocery.services;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.grocery.beans.Product;
import com.grocery.dao.ProductDAO;
import java.util.List;

@WebServlet("/ProductServlet")
public class ProductServlet extends HttpServlet {
    private ProductDAO productDAO;

    @Override
    public void init() {
        productDAO = new ProductDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        switch (action) {
            case "viewProducts":
                viewProducts(request, response);
                break;
            case "deleteProduct":
                deleteProduct(request, response);
                break;
            case "editProduct":
                showEditForm(request, response);
                break;
            default:
                viewProducts(request, response);
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        if ("updateProduct".equals(action)) {
            updateProduct(request, response);
        }
    }

    private void viewProducts(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Product> products = productDAO.getAllProducts();
        request.setAttribute("products", products);
        request.getRequestDispatcher("view-products.jsp").forward(request, response);
    }

    private void deleteProduct(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        boolean isDeleted = productDAO.deleteProduct(id);

        if (isDeleted) {
            request.setAttribute("successMessage", "Product deleted successfully.");
        } else {
            request.setAttribute("errorMessage", "Failed to delete product.");
        }

        viewProducts(request, response);
    }

    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        Product existingProduct = productDAO.getProductById(id);
        request.setAttribute("product", existingProduct);
        request.getRequestDispatcher("update-product.jsp").forward(request, response);
    }

    private void updateProduct(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("productId"));
        String name = request.getParameter("productName");
        String description = request.getParameter("productDescription");
        double price = Double.parseDouble(request.getParameter("price"));
        String category = request.getParameter("category");

        Product product = new Product(id, name, description, price, category);
        boolean isUpdated = productDAO.updateProduct(product);

        if (isUpdated) {
            request.setAttribute("successMessage", "Product updated successfully.");
        } else {
            request.setAttribute("errorMessage", "Failed to update product.");
        }

        viewProducts(request, response);
    }
}
