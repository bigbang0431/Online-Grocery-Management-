

package com.grocery.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.*;




public class DBConnection {
	
	private static final String USER = "user";
    private static final String PASSWORD = "user";

	static Connection conn=null;
	public static Connection getConnection() throws SQLException, ClassNotFoundException {
		Connection conn=null;
		Class.forName("org.sqlite.JDBC");
		String url="jdbc:sqlite:C:/Users/apkee/MySQLiteDB";
		conn=DriverManager.getConnection(url,USER,PASSWORD);
		return conn;
		
	}
	public static void closeConnection(Connection connection) {
		if(connection!=null) {
			try {
				connection.close();
			}
			catch(SQLException e) {
				e.printStackTrace();
			}
			
		}
	}
}





